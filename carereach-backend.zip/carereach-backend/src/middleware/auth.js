// src/middleware/auth.js
// JWT authentication + plan-based feature gating

const jwt = require('jsonwebtoken');

// ── Verify JWT ───────────────────────────────────────────────
const authenticate = (req, res, next) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid authorization header' });
  }
  const token = header.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // { userId, email, plan, tenantId }
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Session expired. Please sign in again.' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// ── Plan Feature Gates ───────────────────────────────────────
const PLAN_LIMITS = {
  starter: {
    leadsPerMonth:    50,
    emailsPerMonth:   500,
    aiContentCalls:   20,
    whiteLabel:       false,
    multiLocation:    false,
    analyticsExport:  false,
  },
  pro: {
    leadsPerMonth:    500,
    emailsPerMonth:   5000,
    aiContentCalls:   200,
    whiteLabel:       false,
    multiLocation:    false,
    analyticsExport:  true,
  },
  agency: {
    leadsPerMonth:    Infinity,
    emailsPerMonth:   Infinity,
    aiContentCalls:   Infinity,
    whiteLabel:       true,
    multiLocation:    true,
    analyticsExport:  true,
  },
};

// Middleware factory: requirePlan('pro') or requireFeature('whiteLabel')
const requirePlan = (...allowedPlans) => (req, res, next) => {
  if (!allowedPlans.includes(req.user?.plan)) {
    return res.status(403).json({
      error: `This feature requires one of these plans: ${allowedPlans.join(', ')}`,
      currentPlan: req.user?.plan,
      upgrade: '/api/billing/upgrade',
    });
  }
  next();
};

const requireFeature = (feature) => (req, res, next) => {
  const limits = PLAN_LIMITS[req.user?.plan];
  if (!limits || !limits[feature]) {
    return res.status(403).json({
      error: `"${feature}" is not available on your current plan.`,
      currentPlan: req.user?.plan,
      upgrade: '/api/billing/upgrade',
    });
  }
  next();
};

// Attach plan limits to req for use in route handlers
const attachLimits = (req, _res, next) => {
  req.planLimits = PLAN_LIMITS[req.user?.plan] || PLAN_LIMITS.starter;
  next();
};

module.exports = { authenticate, requirePlan, requireFeature, attachLimits, PLAN_LIMITS };
